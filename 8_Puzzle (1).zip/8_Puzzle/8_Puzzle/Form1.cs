﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;
using System.Diagnostics;
namespace _8_Puzzle
{
    public partial class Form1 : Form
    {


        string[,] puzzle = new string[3, 3];
        public Form1()
        {
            InitializeComponent();
        }
        public List<string> IDS_Algorithm(string[,] InitialState)
        {
            List<string> solution = new List<string>();
            Stack<node> fringe = new Stack<node>();
            string[,] new_state;
            int limit = 0;
            while (true) //counts the line limits
            {
                node current = new node(InitialState, null, null,0);
                fringe.Push(current);
                while (true) //search for goal state 
                {
                    if (fringe.Count() == 0)
                    {
                        break;
                    }
                    current = fringe.Pop();
                    string[,] current_state = current.value;
                    if (GoalTest(current_state) == true)
                    {
                        node current_node = Copy_Node(current);
                        node parent = Copy_Node(current_node);
                        while(parent.father != null)
                        {
                            solution.Add(current_node.action);
                            parent = Copy_Node( current_node.father);
                            current_node =Copy_Node( parent);
                        }
                        return solution;

                    }
                    if ( current.line< limit) 
                    {
                        int[] empty_home = new int[2];
                        empty_home = FindEmptyOne(current_state);
                        int i = empty_home[0];
                        int j = empty_home[1];
                        string[] acts=WichAction(i, j);
                        node[] successor= new node[4];
                        int h = 0;
                        string[,] now_state;
                        foreach (string a in acts) //Expands the chidren
                        {
                            now_state =Copy_Matrix3X3( current_state);
                            new_state = DoAction(empty_home, a, now_state);
                            successor[h] = new node(new_state, a, current,current.line+1);
                            fringe.Push(successor[h]);
                            h++;


                        }
                       
                    }
                    

                }
                limit++;

            }

        }
        public class node
        {
            public node father;
            public string[,] value;
            public string action;
            public int line;
            public node(string[,] values, string act ,node dad, int l)
            {
                father = dad;
                value = values;
                action = act;
                line = l;
            }
        }
        public node Copy_Node(node previous)
        {
            node new_node = new node(previous.value, previous.action, previous.father,previous.line);
            return new_node;
        }

        public String[,] Copy_Matrix3X3(string[,] m)
        {
            string[,] new_matrix=new string[3,3];
            for(int r=0;r< 3; r++)
            {
                for(int x=0;x< 3; x++)
                {
                    new_matrix[r, x] = m[r, x];
                }
            }
            return new_matrix;
        }
        public string[] WichAction(int i, int j)
            {
                
                if (i == 0 && j == 0) {
                   string[] acts = {  "right","down" };
                   return acts;
                }
                if (i == 0 && j == 1)
                {
                    string[] acts = { "down", "right", "left" };
                    return acts;
                }
                if (i == 0 && j == 2)
                {
                    string[] acts = {  "left","down" };
                    return acts;
                }
                if (i == 1 && j == 0)
                {
                    string[] acts = {  "right", "up" ,"down"};
                    return acts;
                }
                if (i == 1 && j == 1)
                {
                    string[] acts = {  "right", "up", "left" ,"down"};
                    return acts;
                }
                if (i == 1 && j == 2)
                {
                   string[] acts = { "down", "left", "up" };
                   return acts;
                }
                if (i == 2 && j == 0)
                {
                    string[] acts = { "up", "right" };
                    return acts;
                }
                if (i == 2 && j == 1)
                {
                    string[] acts= { "left", "up", "right" };
                    return acts;
                }
            if (i == 2 && j == 2)
            {
                string[] acts = { "up", "left" };
                return acts;
            }
            else
                return null;
            }
        public string[,] DoAction(int[] state,string act,string[,] MyMatrix)
            {
                string[,] MyMatrix2 = new string[3,3];
                MyMatrix2 =Copy_Matrix3X3( MyMatrix);
                if (act == "up")
                {
                MyMatrix2[state[0], state[1]] = MyMatrix2[state[0]-1, state[1]];
                MyMatrix2[state[0]-1, state[1] ] = "";

                }

                if (act == "down")
                {
                MyMatrix2[state[0], state[1]] = MyMatrix2[state[0]+1, state[1]];
                MyMatrix2[state[0]+1, state[1]] = "";
                }

                if (act == "left")
                {
                MyMatrix2[state[0], state[1]] = MyMatrix2[state[0], state[1]-1];
                MyMatrix2[state[0], state[1]-1] = "";
                }

                if (act == "right")
                {
                MyMatrix2[state[0], state[1]] = MyMatrix2[state[0], state[1]+1];
                MyMatrix2[state[0], state[1]+1] = "";
                }
                return MyMatrix2;

            }
        public static bool GoalTest(string[,] puzzle2)
        {
            if (puzzle2[0,0]=="1"&& puzzle2[0,1]=="2"&& puzzle2[0,2]=="3"&&puzzle2[1,0]=="4"&&puzzle2[1,1]=="5"&&puzzle2[1,2]=="6"&&puzzle2[2,0]=="7"&&puzzle2[2,1]=="8"&&puzzle2[2,2]=="")
            {
                return true;
            }
            else

               return false;
        }
        public  int[] FindEmptyOne(string[,] puzzle2)
        {
            int[] location = new int [2];
            for (int i= 0;i <= 2; i++)
            {
                for(int j = 0; j <= 2; j++)
                {
                    if(puzzle2 [i, j] == "")
                    {
                        location[0] = i;
                        location[1] = j;
                        return location;
                    }
                }
            }
            return location;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            string a = button2.Text;
            string b = button6.Text;
            if (a == "")
            {
                button2.Text = button3.Text;
                button2.BackColor = button3.BackColor;
                button3.BackColor = Color.Yellow;
                button3.Text = "";

            }
            if (b == "")
            {
                button6.Text = button3.Text;
                button6.BackColor = button3.BackColor;
                button3.BackColor = Color.Yellow;
                button3.Text = "";

            }
           

        }

        private void button8_Click(object sender, EventArgs e)
        {
            string a = button9.Text;
            string b = button7.Text;
            string c = button5.Text;
            if(a=="")
            {
                button9.Text =button8.Text;
                button9.BackColor = button8.BackColor;
                button8.BackColor = Color.Yellow;
                button8.Text = "";

            }
            if (b == "")
            {
                button7.Text = button8.Text;
                button7.BackColor = button8.BackColor;
                button8.BackColor = Color.Yellow;
                button8.Text = "";

            }
            if (c == "")
            {
                button5.Text = button8.Text;
                button5.BackColor = button8.BackColor;
                button8.BackColor = Color.Yellow;
                button8.Text = "";

            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string a = button2.Text;
            string b = button4.Text;
            if (a == "")
            {
                button2.Text = button1.Text;
                button2.BackColor = button1.BackColor;
                button1.BackColor = Color.Yellow;
                button1.Text = "";

            }
            if (b == "")
            {
                button4.Text = button1.Text;
                button4.BackColor = button1.BackColor;
                button1.BackColor = Color.Yellow;
                button1.Text = "";

            }
           
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string a = button1.Text;
            string b = button3.Text;
            string c = button5.Text;
            if (a == "")
            {
                button1.Text = button2.Text;
                button1.BackColor = button2.BackColor;
                button2.BackColor = Color.Yellow;
                button2.Text = "";

            }
            if (b == "")
            {
                button3.Text = button2.Text;
                button3.BackColor = button2.BackColor;
                button2.BackColor = Color.Yellow;
                button2.Text = "";

            }
            if (c == "")
            {
                button5.Text = button2.Text;
                button5.BackColor = button2.BackColor;
                button2.BackColor = Color.Yellow;
                button2.Text = "";

            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            string a = button1.Text;
            string b = button5.Text;
            string c = button7.Text;
            if (a == "")
            {
                button1.Text = button4.Text;
                button1.BackColor = button4.BackColor;
                button4.BackColor = Color.Yellow;
                button4.Text = "";

            }
            if (b == "")
            {
                button5.Text = button4.Text;
                button5.BackColor = button4.BackColor;
                button4.BackColor = Color.Yellow;
                button4.Text = "";

            }
            if (c == "")
            {
                button7.Text = button4.Text;
                button7.BackColor = button4.BackColor;
                button4.BackColor = Color.Yellow;
                button4.Text = "";

            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            string a = button2.Text;
            string b = button4.Text;
            string c = button6.Text;
            string d = button8.Text;
            if (a == "")
            {
                button2.Text = button5.Text;
                button2.BackColor = button5.BackColor;
                button5.BackColor = Color.Yellow;
                button5.Text = "";

            }
            if (b == "")
            {
                button4.Text = button5.Text;
                button4.BackColor = button5.BackColor;
                button5.BackColor = Color.Yellow;
                button5.Text = "";

            }
            if (c == "")
            {
                button6.Text = button5.Text;
                button6.BackColor = button5.BackColor;
                button5.BackColor = Color.Yellow;
                button5.Text = "";

            }
            if (d == "")
            {
                button8.Text = button5.Text;
                button8.BackColor = button5.BackColor;
                button5.BackColor = Color.Yellow;
                button5.Text = "";
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            string a = button3.Text;
            string b = button5.Text;
            string c = button9.Text;
            if (a == "")
            {
                button3.Text = button6.Text;
                button3.BackColor = button6.BackColor;
                button6.BackColor = Color.Yellow;
                button6.Text = "";

            }
            if (b == "")
            {
                button5.Text = button6.Text;
                button5.BackColor = button6.BackColor;
                button6.BackColor = Color.Yellow;
                button6.Text = "";

            }
            if (c == "")
            {
                button9.Text = button6.Text;
                button9.BackColor = button6.BackColor;
                button6.BackColor = Color.Yellow;
                button6.Text = "";

            }
        }

        private void button7_Click(object sender, EventArgs e)
        {
            string a = button4.Text;
            string b = button8.Text;
            if (a == "")
            {
                button4.Text = button7.Text;
                button4.BackColor = button7.BackColor;
                button7.BackColor = Color.Yellow;
                button7.Text = "";

            }
            if (b == "")
            {
                button8.Text = button7.Text;
                button8.BackColor = button7.BackColor;
                button7.BackColor = Color.Yellow;
                button7.Text = "";

            }
        }

        private void button9_Click(object sender, EventArgs e)
        {
            string a = button6.Text;
            string b = button8.Text;
            if (a == "")
            {
                button6.Text = button9.Text;
                button6.BackColor = button9.BackColor;
                button9.BackColor = Color.Yellow;
                button9.Text = "";

            }
            if (b == "")
            {
                button8.Text = button9.Text;
                button8.BackColor = button9.BackColor;
                button9.BackColor = Color.Yellow;
                button9.Text = "";

            }
        }

        private void button10_Click(object sender, EventArgs e)
        {
            puzzle[0, 0] = button1.Text;
            puzzle[0, 1] = button2.Text;
            puzzle[0, 2] = button3.Text;
            puzzle[1, 0] = button4.Text;
            puzzle[1, 1] = button5.Text;
            puzzle[1, 2] = button6.Text;
            puzzle[2, 0] = button7.Text;
            puzzle[2, 1] = button8.Text;
            puzzle[2, 2] = button9.Text;
            List<string> MySolution;
            MySolution = IDS_Algorithm(puzzle);
            string[,] current_matrix2 = new string[3, 3];
            current_matrix2 =Copy_Matrix3X3( puzzle);
            int[] EmptyLocation;
            label1.Text = "Here is your solution!!!";
            if (MySolution.Count >= 1)
            {
                listBox1.Visible = true;
                for (int i = MySolution.Count-1; i >= 0; i--)
                {
                    listBox1.Items.Add(MySolution[i]);
                    EmptyLocation = FindEmptyOne(current_matrix2);
                    current_matrix2 = Copy_Matrix3X3( DoAction(EmptyLocation, MySolution[i], current_matrix2));
                    button1.Text = current_matrix2[0, 0];
                    button2.Text = current_matrix2[0, 1];
                    button3.Text = current_matrix2[0, 2];
                    button4.Text = current_matrix2[1, 0];
                    button5.Text = current_matrix2[1, 1];
                    button6.Text = current_matrix2[1, 2];
                    button7.Text = current_matrix2[2, 0];
                    button8.Text = current_matrix2[2, 1];
                    button9.Text = current_matrix2[2, 2];
                    if (current_matrix2[0, 0] == "")
                        button1.BackColor = Color.Yellow;
                    else
                        button1.BackColor = Color.Turquoise;
                    if (current_matrix2[0, 1] == "")
                        button2.BackColor = Color.Yellow;
                    else
                        button2.BackColor = Color.Turquoise;
                    if (current_matrix2[0, 2] == "")
                        button3.BackColor = Color.Yellow;
                    else
                        button3.BackColor = Color.Turquoise;
                    if (current_matrix2[1, 0] == "")
                        button4.BackColor = Color.Yellow;
                    else
                        button4.BackColor = Color.Turquoise;
                    if (current_matrix2[1, 1] == "")
                        button5.BackColor = Color.Yellow;
                    else
                        button5.BackColor = Color.Turquoise;
                    if (current_matrix2[1, 2] == "")
                        button6.BackColor = Color.Yellow;
                    else
                        button6.BackColor = Color.Turquoise;
                    if (current_matrix2[2, 0] == "")
                        button7.BackColor = Color.Yellow;
                    else
                        button7.BackColor = Color.Turquoise;
                    if (current_matrix2[2, 1] == "")
                        button8.BackColor = Color.Yellow;
                    else
                        button8.BackColor = Color.Turquoise;
                    if (current_matrix2[2, 2] == "")
                        button9.BackColor = Color.Yellow;
                    else
                        button9.BackColor = Color.Turquoise;

                     Thread.Sleep(700);
                    this.Refresh();
                }
                listBox1.Items.Add("------------------------------------");
            }
            






        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

     
    }
}
